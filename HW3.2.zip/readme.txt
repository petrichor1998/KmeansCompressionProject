Code submitted by : Parth Padalkar, PXP180054

Part 2 : Kmeans
Description :
The code runs the kmeans algorithm for the user input value of K and an image file. It returns a compressed image file and stores it in the current directory.

Running the code :
store the image in the same directory as the code and run the following command for different values of K
example command:
python kmeans.py -image "Koala.jpg" -K 2 



